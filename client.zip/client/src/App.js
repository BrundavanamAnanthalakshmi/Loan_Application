import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import AdminLogin from "./components/AdminLogin";
import SignUp from "./components/Signup";
import UserAccess from "./components/UserAccess";
import AdminDashboard from "./components/AdminDashboard";
import Home from "./components/Home";
import LoanApplication from "./components/LoanApplication";
import Feedback from "./components/Feedback";
import LoanApplicationView from "./components/LoanApplicationView";
import Login from "./components/Login";
import Contact from "./components/Contact";

function App() {
  return (
    <Router>
      <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/admin-login" element={<AdminLogin />} />
          <Route path="/admin-dashboard" element={<AdminDashboard />} />
          <Route path="/user-access" element={<UserAccess />} />
          <Route path="/loan-application" element={<LoanApplication />} />
          <Route path="/feedback" element={<Feedback />} />
          {/* <Route path="/view" element={<AdminViewApplication />} />  */}
          <Route path="/signup" element={<SignUp />} />
          <Route path="/login" element={<Login />} />
          <Route path="/contact" element={<Contact />} />

          <Route path="/admin" element={<AdminDashboard/>} />
          <Route
            path="/admin/applications/:id"
            element={<LoanApplicationView />}
          />
        </Routes>

    </Router>
  );
}

export default App;
