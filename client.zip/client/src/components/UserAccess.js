import React from "react";
import Login from "./Login";  // Ensure Login.js exists in the same folder

function UserAccess() {
  return (
    <div>
      <Login />
    </div>
  );
}

export default UserAccess;
