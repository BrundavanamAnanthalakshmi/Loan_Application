import React, { useState } from "react";

function Contact() {
  const [formData, setFormData] = useState({
    name: "Your Name",
    email: "sample@gmail.com",
    message: "Don't hesitate to contact us. We are here to assist you!"
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Your message has been sent!");
  };

  return (
    <div style={styles.contactContainer}>
      <div style={styles.content}>
        <div style={styles.contactFormSection}>
          <h1 style={styles.contactTitle}>Contact Us</h1>
          <p style={styles.contactSubtitle}>We'd love to hear from you!</p>

          <form onSubmit={handleSubmit}>
            <div style={styles.formGroup}>
              <label style={styles.label}>Name</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                style={styles.input}
              />
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Email</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                style={styles.input}
              />
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Message</label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                style={styles.textarea}
              />
            </div>

            <button type="submit" style={styles.submitBtn}>
              Send Message
            </button>
          </form>

       
          <div style={styles.contactNumber}>
            <p>Contact us at: <strong>+91 000000000</strong></p>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  contactContainer: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    minHeight: "100vh",
    background: "url('https://static.vecteezy.com/system/resources/previews/020/804/109/non_2x/communication-and-technology-concept-hand-putting-wooden-block-cube-symbol-telephone-email-address-website-page-contact-us-or-e-mail-marketing-contact-us-in-customer-support-concept-photo.jpg') no-repeat center center fixed",
    backgroundSize: "cover",
    position: "relative",
    textAlign: "center",
    color: "white"
  },
  content: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "column"
  },
  contactFormSection: {
    color: "white",
    maxWidth: "900px",
    margin: "0 auto",
    background: "rgba(0, 0, 0, 0.5)", 
    padding: "50px",
    borderRadius: "10px"
  },
  contactTitle: {
    fontSize: "3.5rem",
    fontWeight: "bold",
    marginBottom: "20px",
    textTransform: "uppercase",
    animation: "slideInDown 1s ease-out"
  },
  contactSubtitle: {
    fontSize: "1.5rem",
    marginBottom: "30px",
    animation: "slideInUp 1s ease-out"
  },
  formGroup: {
    marginBottom: "20px"
  },
  label: {
    display: "block",
    fontSize: "14px",
    marginBottom: "5px",
    color: "white"
  },
  input: {
    width: "100%",
    padding: "10px",
    fontSize: "16px",
    border: "none",
    borderRadius: "5px",
    outline: "none",
    backgroundColor: "#333",
    color: "white",
    boxSizing: "border-box"
  },
  textarea: {
    width: "100%",
    padding: "10px",
    fontSize: "16px",
    border: "none",
    borderRadius: "5px",
    outline: "none",
    backgroundColor: "#333",
    color: "white",
    height: "150px",
    resize: "none"
  },
  submitBtn: {
    width: "100%",
    padding: "12px",
    backgroundColor: "#00f1ff",
    border: "none",
    borderRadius: "5px",
    fontSize: "16px",
    color: "white",
    cursor: "pointer",
    transition: "all 0.3s ease",
    boxShadow: "0 4px 10px rgba(0, 255, 255, 0.3)"
  },
  submitBtnHover: {
    backgroundColor: "#008c8c",
    boxShadow: "0 6px 15px rgba(0, 255, 255, 0.4)",
    transform: "translateY(-3px)"
  },
  contactNumber: {
    marginTop: "20px",
    fontSize: "1.2rem",
    color: "white",
    fontWeight: "bold",
    animation: "slideInUp 1s ease-out"
  }
};

// Adding animations for title and subtitle
// const animationStyles = `
//   @keyframes slideInDown {
//     from { transform: translateY(-100%); opacity: 0; }
//     to { transform: translateY(0); opacity: 1; }
//   }

//   @keyframes slideInUp {
//     from { transform: translateY(100%); opacity: 0; }
//     to { transform: translateY(0); opacity: 1; }
//   }
// `;

export default Contact;