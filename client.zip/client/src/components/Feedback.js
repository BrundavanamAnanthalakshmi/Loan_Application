import React from "react";
import "./Feedback.css"; 

const Feedback = () => {
  return (
    <div className="feedback-container">
      <h2>Thank you for submitting the application!</h2>
      <p className="thank-you-message">We will reach out to you soon.</p>
    </div>
  );
};

export default Feedback;
