import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Loan.css';

function Loanapplication() {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        age: '',
        address: '',
        monthlyIncome: '',
        loanAmount: '',
        tenure: '',
        cibilScore: '',
        dti: '',
        currentBalances: '',
        employerName: '',
        employerDesignation: '',
        annualIncome: ''
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const validateForm = () => {
        const { name, email, phone, age, monthlyIncome, loanAmount, cibilScore, dti } = formData;
        if (!name || !email || !phone || !age || !monthlyIncome || !loanAmount || !cibilScore || !dti) {
            alert('Please fill in all required fields.');
            return false;
        }
        if (isNaN(age) || isNaN(monthlyIncome) || isNaN(loanAmount) || isNaN(cibilScore) || isNaN(dti)) {
            alert('Please enter valid numbers for all fields that require them.');
            return false;
        }
        return true;
    };
    const handleLogout = () => {
     
        navigate('/');
    }
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validateForm()) return;

        try {
            const response = await axios.post('http://localhost:5000/api/loan/apply', formData);
            alert(response.data.message); 
            navigate('/feedback');  
        } catch (err) {
            const errorMessage = err.response?.data?.message || "An unexpected error occurred. Please try again.";
            alert('Error: ' + errorMessage);
        }
    };

    return (
        <div className="loan-application-container">
            <h2>Loan Application</h2>
            <button className="logout-button" onClick={handleLogout}>Logout</button>
            <form onSubmit={handleSubmit} className="loan-form">
        
                <input type="text" name="name" value={formData.name} onChange={handleChange} placeholder="Name" required />
                <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Email" required />
                <input type="text" name="phone" value={formData.phone} onChange={handleChange} placeholder="Phone" required />
                <input type="number" name="age" value={formData.age} onChange={handleChange} placeholder="Age" required />
                <input type="text" name="address" value={formData.address} onChange={handleChange} placeholder="Address" />

                <input type="number" name="monthlyIncome" value={formData.monthlyIncome} onChange={handleChange} placeholder="Monthly Income" required />
                <input type="number" name="loanAmount" value={formData.loanAmount} onChange={handleChange} placeholder="Requested Loan Amount" required />
                <input type="number" name="tenure" value={formData.tenure} onChange={handleChange} placeholder="Tenure (Months)" />

                <input type="number" name="cibilScore" value={formData.cibilScore} onChange={handleChange} placeholder="CIBIL Score" required />
                <input type="number" name="dti" value={formData.dti} onChange={handleChange} placeholder="Debt-to-Income Ratio" required />
                <input type="number" name="currentBalances" value={formData.currentBalances} onChange={handleChange} placeholder="Current Debt Balances" />

                <input type="text" name="employerName" value={formData.employerName} onChange={handleChange} placeholder="Employer Name" />
                <input type="text" name="employerDesignation" value={formData.employerDesignation} onChange={handleChange} placeholder="Employer Designation" />
                <input type="number" name="annualIncome" value={formData.annualIncome} onChange={handleChange} placeholder="Annual Income" />

                <button type="submit">Submit Application</button>
            </form>
        </div>
    );
}

export default Loanapplication;
