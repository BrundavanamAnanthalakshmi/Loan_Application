import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './AdminDashboard.css'; // Import the CSS file

function AdminDashboard() {
    const [applications, setApplications] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        axios.get('http://localhost:5000/api/loan/applications')
            .then((response) => {
                setApplications(response.data || []);
                setLoading(false);
            })
            .catch((err) => {
                console.error('Error fetching applications:', err);
                setApplications([]);
                setLoading(false);
            });
    }, []);

    const handleView = (id) => {
        navigate(`/admin/applications/${id}`);
    };
    const handleLogout = () => {
        navigate('/');
    };

    if (loading) {
        return <div className="loading">Loading applications...</div>;
    }

    return (
        <div className="dashboard-container">
            <div className="dashboard-header">
                <h2 className="dashboard-title">Admin Dashboard</h2>
                <button className="logout-button" onClick={handleLogout}>Logout</button>
            </div>
            {Array.isArray(applications) && applications.length === 0 ? (
                <p className="no-data">No applications found.</p>
            ) : (
                <div className="applications-container">
                    {applications.map((app) => (
                        <div key={app._id} className="application-card">
                            <p><strong>Name:</strong> {app.name}</p>
                            <p><strong>Loan Amount:</strong> ₹{app.loanAmount}</p>
                            <p><strong>Tenure:</strong> {app.tenure} months</p>
                            <p><strong>Timestamp:</strong> {app.createdAt ? new Date(app.createdAt).toLocaleString() : 'No date'}</p>
                            <button className="view-button" onClick={() => handleView(app._id)}>View</button>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

export default AdminDashboard;
