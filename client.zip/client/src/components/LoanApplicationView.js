import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams,useNavigate} from "react-router-dom";
import { jsPDF } from "jspdf";

function LoanApplicationView() {
  const { id } = useParams(); // Get application ID from URL
  const [applicationDetails, setApplicationDetails] = useState(null);
  const [assessmentResult, setAssessmentResult] = useState(null);
  const navigate=useNavigate();
  const handleLogout = () => {
    navigate('/');
};

  useEffect(() => {
    // Fetch loan application details by ID
    axios
      .get(`http://localhost:5000/api/loan/applications/${id}`)
      .then((response) => {
        setApplicationDetails(response.data); // Set application details
        assessEligibility(response.data); // Assess eligibility
      })
      .catch((err) => {
        console.error("Error fetching application details:", err);
      });
  }, [id]);

  const assessEligibility = (application) => {
    const { cibilScore, dti, annualIncome, loanAmount } = application;

    const creditworthinessScore = cibilScore >= 700 && dti < 0.3 ? 50 : 0; // CIBIL and DTI check
    const financialStabilityScore = annualIncome >= loanAmount * 3 ? 50 : 0; // Income vs loan amount check

    const totalScore = creditworthinessScore + financialStabilityScore;

    let result = "";

    if (totalScore >= 80) {
      result = {
        text: `The user is eligible for a loan of ₹${loanAmount}.`,
        eligibility: "Eligible",
      };
    } else {
      const maxEligibleLoan = Math.floor(annualIncome * 0.5); // Calculating max eligible loan
      result = {
        text: `The user is not eligible for the requested loan. However, they can avail a loan of ₹${maxEligibleLoan}.`,
        eligibility: "Not Eligible",
      };
    }

    setAssessmentResult(result);
  };

  // Download report as PDF
  const downloadPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text("Loan Report Card", 10, 10);

    doc.setFontSize(12);
    doc.text(`Name: ${applicationDetails.name}`, 10, 20);
    doc.text(
      `Loan Amount Requested: ₹${applicationDetails.loanAmount}`,
      10,
      30
    );
    doc.text(`Tenure: ${applicationDetails.tenure} months`, 10, 40);
    doc.text(`CIBIL Score: ${applicationDetails.cibilScore}`, 10, 50);
    doc.text(
      `Debt-to-Income Ratio (DTI): ${applicationDetails.dti}`,
      10,
      60
    );
    doc.text(`Annual Income: ₹${applicationDetails.annualIncome}`, 10, 70);
    doc.text(`Employer: ${applicationDetails.employer}`, 10, 80);
    doc.text(
      `Repayment Method: ${applicationDetails.repaymentMethod}`,
      10,
      90
    );
    doc.text(
      `Submission Timestamp: ${new Date(
        applicationDetails.createdAt
      ).toLocaleString()}`,
      10,
      100
    );

    doc.setFontSize(14);
    doc.text("Credit Assessment Result", 10, 120);
    doc.setFontSize(12);
    doc.text(
      assessmentResult
        ? assessmentResult.text
        : "Eligibility assessment pending...",
      10,
      130
    );

    doc.save(`${applicationDetails.name}_Loan_Report.pdf`);
  };

  if (!applicationDetails) {
    return <div>Loading application details...</div>;
  }

  return (
    <>
    <div className="dashboard-header">
    <h2 className="dashboard-title">Applicant Details</h2>
    <button className="logout-button" onClick={handleLogout}>Logout</button>
</div>
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.title}>Loan Application Details</h2>
        <div style={styles.detailRow}>
          <strong>Name:</strong> {applicationDetails.name}
        </div>
        <div style={styles.detailRow}>
          <strong>Loan Amount Requested:</strong> ₹{applicationDetails.loanAmount}
        </div>
        <div style={styles.detailRow}>
          <strong>Tenure:</strong> {applicationDetails.tenure} months
        </div>
        <div style={styles.detailRow}>
          <strong>CIBIL Score:</strong> {applicationDetails.cibilScore}
        </div>
        <div style={styles.detailRow}>
          <strong>Debt-to-Income Ratio (DTI):</strong> {applicationDetails.dti}
        </div>
        <div style={styles.detailRow}>
          <strong>Annual Income:</strong> ₹{applicationDetails.annualIncome}
        </div>
        <div style={styles.detailRow}>
          <strong>Employer:</strong> {applicationDetails.employer}
        </div>
        <div style={styles.detailRow}>
          <strong>Repayment Method:</strong> {applicationDetails.repaymentMethod}
        </div>
        <div style={styles.detailRow}>
          <strong>Submission Timestamp:</strong>{" "}
          {new Date(applicationDetails.createdAt).toLocaleString()}
        </div>

        <h3 style={styles.subTitle}>Credit Assessment Result</h3>
        <div style={styles.detailRow}>
          {assessmentResult ? assessmentResult.text : "Assessing eligibility..."}
        </div>
        {assessmentResult && (
          <div
            style={{
              ...styles.eligibilityBox,
              backgroundColor:
                assessmentResult.eligibility === "Eligible" ? "#d4edda" : "#f8d7da",
              color:
                assessmentResult.eligibility === "Eligible" ? "#155724" : "#721c24",
            }}
          >
            {assessmentResult.eligibility}
          </div>
        )}

        <button style={styles.button} onClick={downloadPDF}>
          Download Report as PDF
        </button>
      </div>
    </div>
    </>
  );
}

const styles = {
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100vh",
    backgroundColor: "#f8f9fa",
    padding: "20px",
  },
  card: {
    backgroundColor: "#fff",
    padding: "30px",
    borderRadius: "12px",
    boxShadow: "0 8px 16px rgba(0, 0, 0, 0.1)",
    width: "500px",
    textAlign: "left",
  },
  title: {
    marginBottom: "20px",
    fontSize: "24px",
    fontWeight: "bold",
    color: "#333",
    textAlign: "center",
  },
  subTitle: {
    marginTop: "20px",
    fontSize: "20px",
    fontWeight: "bold",
    color: "#555",
    textAlign: "center",
  },
  detailRow: {
    marginBottom: "10px",
    fontSize: "16px",
    color: "#444",
  },
  eligibilityBox: {
    marginTop: "20px",
    padding: "15px",
    borderRadius: "8px",
    fontWeight: "bold",
    textAlign: "center",
    fontSize: "18px",
  },
  button: {
    display: "block",
    margin: "20px auto 0",
    padding: "12px 25px",
    backgroundColor: "#007BFF",
    color: "#fff",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "16px",
  },
};

export default LoanApplicationView;
