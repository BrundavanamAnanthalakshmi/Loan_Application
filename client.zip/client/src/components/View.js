// components/AdminViewApplication.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

function AdminViewApplication() {
    const { id } = useParams();
    const [application, setApplication] = useState(null);
    const [decision, setDecision] = useState('');

    useEffect(() => {
        axios.get(`http://localhost:5000/api/loan/apply/${id}`)
            .then((response) => {
                setApplication(response.data);
                evaluateLoan(response.data);
            })
            .catch((err) => {
                console.error('Error fetching application details:', err);
            });
    }, [id]);

    const evaluateLoan = (app) => {
        const creditworthiness = (app.cibilScore / 900) * 50; // 50% weight
        const stability = ((app.annualIncome / (app.loanAmount * 3)) * 50); // 50% weight
        const totalScore = creditworthiness + stability;

        if (totalScore > 80) {
            setDecision(`Eligible for up to ₹${app.loanAmount}`);
        } else if (totalScore > 60) {
            setDecision(`Eligible for ₹${app.loanAmount * 0.75}`);
        } else {
            setDecision('Not Eligible');
        }
    };

    if (!application) return <div>Loading...</div>;

    return (
        <div>
            <h2>Application Details</h2>
            <div><strong>Name:</strong> {application.name}</div>
            <div><strong>Email:</strong> {application.email}</div>
            <div><strong>Phone:</strong> {application.phone}</div>
            <div><strong>Loan Amount:</strong> ₹{application.loanAmount}</div>
            <div><strong>Tenure:</strong> {application.tenure} months</div>
            <div><strong>Status:</strong> {application.status}</div>
            <div><strong>Decision:</strong> {decision}</div>
        </div>
    );
}

export default AdminViewApplication;
