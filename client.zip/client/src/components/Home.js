import React from "react";
import "./Home.css";

function Home() {
  return (
    <div className="home-container">
      <h1 className="home-title">Welcome to Loan Application Portal</h1>
    </div>
  );
}

export default Home;
