const LoanApplication = require("../models/LoanApplication");

// Loan Application submission logic
exports.submitApplication = async (req, res) => {
  try {
    const {
      name,
      email,
      phone,
      age,
      address,
      monthlyIncome,
      loanAmount,
      tenure,
      cibilScore,
      dti,
      currentBalances,
      employerName,
      employerDesignation,
      annualIncome,
    } = req.body;
    
    const existingApplication = await LoanApplication.findOne({
      $or: [{ email }, { phone }],
    });

    if (existingApplication) {
      return res.status(400).json({
        message: "User with this email or phone already exists",
      });
    }

    // Calculate creditworthiness and financial stability
    let creditworthinessScore = calculateCreditworthiness(cibilScore, dti);
    let financialStabilityScore = calculateFinancialStability(
      annualIncome,
      loanAmount,
      employerName
    );

    // Overall decision
    let eligibility = "Not Eligible";
    if (creditworthinessScore + financialStabilityScore > 80) {
      eligibility = "Eligible";
    }

    const newLoanApplication = new LoanApplication({
      name,
      email,
      phone,
      age,
      address,
      monthlyIncome,
      loanAmount,
      tenure,
      cibilScore,
      dti,
      currentBalances,
      employerName,
      employerDesignation,
      annualIncome,
      status: eligibility,
    });

    await newLoanApplication.save();
    res.json({ message: "Application Submitted" });
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error processing loan application", error: err });
  }
};

// Get all loan applications (Admin use)
exports.getAllApplications = async (req, res) => {
  try {
    const applications = await LoanApplication.find();
    res.json(applications);
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error fetching loan applications", error: err });
  }
};

exports.getApplicationById = async (req, res) => {
  try {
    const { id } = req.params;
    const application = await LoanApplication.findById(id);
    if (!application) {
      return res.status(404).json({ message: "Application not found" });
    }
    res.json(application);
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error fetching application details", error: err });
  }
};
// Creditworthiness logic (CIBIL score + DTI)
function calculateCreditworthiness(cibilScore, dti) {
  let score = 0;
  if (cibilScore >= 750) score += 50;
  else if (cibilScore >= 700) score += 40;

  if (dti < 0.3) score += 50;
  else if (dti < 0.5) score += 30;

  return score;
}

// Financial stability logic (Income vs Loan Amount)
function calculateFinancialStability(annualIncome, loanAmount, employerName) {
  let score = 0;
  if (annualIncome > loanAmount * 3) score += 50;
  else if (annualIncome > loanAmount * 2) score += 30;

  if (employerName) score += 20;

  return score;
}
