const mongoose = require("mongoose");

const LoanApplicationSchema = new mongoose.Schema({
  name: String,
  email: String,
  phone: String,
  age: Number,
  address: String,
  monthlyIncome: Number,
  loanAmount: Number,
  tenure: Number,
  cibilScore: Number,
  dti: Number,
  currentBalances: Number,
  employerName: String,
  employerDesignation: String,
  annualIncome: Number,
  status: { type: String, default: 'Pending' }, // Default status is 'Pending'
},
{ timestamps: true } // This will automatically add `createdAt` and `updatedAt` fields
);

module.exports = mongoose.model("LoanApplication", LoanApplicationSchema);
