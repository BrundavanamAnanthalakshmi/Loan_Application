const express = require("express");
const router = express.Router();
const Loancontroller = require("../controllers/Loancontroller")

// Sample Loan Route (Modify as needed)
router.post("/apply", Loancontroller.submitApplication);

// Route to fetch all loan applications (GET) - for admin dashboard
router.get("/applications", Loancontroller.getAllApplications);



router.get("/applications/:id", Loancontroller.getApplicationById);


module.exports = router;
